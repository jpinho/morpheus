# Morpheus — the Ceiling vs. Effort skill

A Claude Code skill that encodes how to drive AI coding agents: pick the model **tier**
(the ceiling) and the thinking **effort** per call, and orchestrate multi-step work with a
five-move recipe — **drive → delegate down → escalate up → verify sideways → judge**.

It's self-improving: it reads and appends its own `LESSONS.md`, so it sharpens with use.

## Install (Claude Code)

Copy the `morpheus/` folder into your personal skills directory:

    ~/.claude/skills/morpheus/

That's the whole install. The skill triggers when a request is about *how to run an agent* —
which model, how much effort, how to split the work — not just what to build. Open
`SKILL.md` for the framework and the decision table.

## What's inside

- `SKILL.md` — the framework, the tier/effort decision table, the recipe, the anti-patterns,
  and the self-improvement loop.
- `LESSONS.md` — seed lessons the skill learned in practice (genericized for this public copy).

From the talk **"Ceiling vs. Effort — how to actually drive AI agents"** by João Pinho.
