---
name: morpheus
description: >-
  Reach for this whenever a request carries a question about *how to run an AI agent*, not
  just what to build. Signals: choosing a model tier ("Haiku or something bigger?",
  cheapest/fastest way to run an agent over a codebase, "point fable at it or is there a
  smarter way?"), how hard it should think, or how to structure multi-agent work – spawning
  a subagent, driving one through a hard bug or architecture call, wiring a second agent to
  refute and actually catch problems instead of rubber-stamping, or fanning out a migration,
  mass triage, or parallel job without it being slow or costly. The underlying task can be
  anything (bug, refactor, review, triage, cleanup); what triggers is the meta-decision of
  which model, how much effort, and how to orchestrate. Skip when the user just wants the
  task done, a plain price or spec lookup, prompt A/B testing, doc summarizing, or non-agent
  automation like cron jobs.
---

# Morpheus

The **Ceiling vs. Effort** framework for driving AI agents. Spend model capability and
thinking budget on purpose, and orchestrate agents so the expensive judgment happens
exactly where it pays off.

**Before applying, read `LESSONS.md` in this skill's directory.** It holds concrete lessons
from past runs and is the reason this skill gets sharper over time. After a non-trivial
application, add what you learned back (see [The self-improvement loop](#the-self-improvement-loop)).

## The two dials

Model choice is two independent dials, not one. Confusing them is the most common and
expensive mistake.

- **Tier** = the *ceiling* (Haiku → Sonnet → Opus → Fable). Raw capability: reasoning,
  knowledge, holding state, following instructions. A weaker model thinking harder never
  reaches a stronger model's ceiling.
- **Effort** = the *deliberation* (`low → medium → high → xhigh → max`). How many thinking
  tokens the model burns before it answers. More effort lets a model use the capability it
  already has — explore branches, catch its own mistakes, verify — but it can't add
  capability that isn't there.

They fail differently. On a hard, ambiguous problem the ceiling decides the outcome, so spend
on **tier**. On a clear, tedious, well-specified problem spend on **effort** (or neither).
`max` is not "best" — it overthinks; `xhigh` is the sweet spot for coding and agentic work,
`high` the sensible default.

Not every surface exposes both dials. Some models (e.g. Haiku) have no effort setting, and
many "spawn a subagent" tools only let you pick tier — there you approximate effort by how
tightly you scope the prompt. Check what you actually control before assuming you have both.

## Pick tier and effort

| Situation | Tier | Effort |
|---|---|---|
| Mechanical, high-volume, fully specified (rename, format, parse, fan-out reads) | Haiku | none needed — cheapest tier |
| Most coding, exploration, scoped features — the default | Sonnet | medium–high |
| Hard coding, long-horizon agentic work (multi-file refactor, autonomous loop) | Sonnet / Opus | xhigh |
| Subtle bug, architecture call, threat model — expensive if wrong | Opus | high–xhigh |
| The genuinely hardest thing you have | Fable | high+ |

Default down and escalate on purpose. Reaching for the top tier by reflex is expensive and
often worse: a big model on a small task adds latency and cost, not quality.

**Cost frame:** roughly Haiku 1× / Sonnet 3× / Opus 5× / Fable 10× per token. Effort
multiplies the token *count* (thinking bills at the output rate), so the two dials compound.
Top tier at top effort is a scalpel, never a default.

## The recipe — one shape, always

Multi-step work rarely resolves in a single tier-vs-effort call; the value compounds across a
chain. Run the same five moves every time and vary only tier and effort per step.

1. **Drive** — keep the main loop in one place (one driver, usually Sonnet at medium–high).
   Don't switch the driver mid-task; it wrecks the cache and scatters context.
2. **Delegate down** — hand fan-out reads, searches, and mechanical edits to the cheapest
   tier (Haiku). This is context hygiene as much as cost: large contexts lose accuracy as
   they fill, so distil what the driver ingests. Route big raw dumps (API responses, logs,
   CSVs) through a cheap sub-agent that returns only what matters, and compact aggressively.
3. **Escalate up** — isolate the one genuinely hard sub-problem and give it to a top tier at
   high effort. One scalpel, not a blanket over the whole task.
4. **Verify sideways** — before shipping anything expensive-if-wrong, spawn a fresh,
   independent agent and prompt it to *refute*, not review: "find what's wrong with this;
   default to refuted if unsure." Majority-refute kills the finding. This is the step that
   catches a wrong *diagnosis* — the failure mode tier and effort do not fix.
5. **Judge, don't average** — with N parallel attempts, score them and take the winner
   (grafting the best of the rest). Averaging gives you the mush in the middle.

Don't verify everything — verify the decisions that are costly to get wrong. That's usually a
small fraction of the steps, and where the whole method earns its keep.

## Anti-patterns

- **Top tier / max effort by reflex.** Expensive, and frequently worse than xhigh.
- **Averaging parallel outputs** instead of judging and picking a winner.
- **Same-family "verification."** Correlated failures aren't verification. Tier-diversity is
  not vendor-diversity: Opus refuting Sonnet feels independent but shares the same blind
  spots. Real independence usually means a different vendor family.
- **Polite review prompts.** "Review this" gets agreement; you have to ask it to refute.
- **Pasting raw dumps into the driver** instead of distilling first — they ride at
  driver-rate and pollute the context every turn after.
- **Trusting a mechanical-looking step.** Nested or ambiguous extraction often needs more
  tier than it looks (see LESSONS.md).

## The self-improvement loop

This skill is meant to get sharper with use. The mechanism is a plain file, `LESSONS.md`, in
this skill's directory.

**Before applying:** read `LESSONS.md` and skim for lessons relevant to the task at hand —
the tier you're tempted to pick, the kind of work, past cost surprises.

**After a non-trivial application:** if you learned something that would change a future call,
append one lesson. Record only things that would actually change behavior: a tier choice that
was wrong, a mechanical task that wasn't, a verify pass that caught (or missed) a real error, a
cost that surprised you. Skip the trivial and anything already captured.

Format — one lesson per entry, newest first, terse:

```
## <short title> — <YYYY-MM-DD>
**What happened:** one or two concrete sentences.
**Why it matters:** the general principle behind it.
**How to apply:** the change to make next time.
```

Keep the file lean. When it passes ~20 lessons or several say the same thing, consolidate: fold
repeats into one sharper lesson, and promote anything that has hardened into a rule up into
this SKILL.md (Anti-patterns or the decision table). A lesson that keeps recurring is no longer
a lesson — it's part of the framework.
