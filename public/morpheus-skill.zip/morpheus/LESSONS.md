# Lessons — morpheus (Ceiling vs. Effort)

Concrete lessons from applying the framework. Read before orchestrating; append after.
Newest first, one lesson per entry. Keep it terse and consolidate when it grows
(see SKILL.md → The self-improvement loop).

> This is the public seed copy; specifics from the original ticket have been genericized.

## Solo top-tier misdiagnosed a bug the orchestrated recipe caught
**What happened:** The same real ticket (a duplicate-looking entry in a permissions dropdown)
was run two ways. A single top-tier model at max effort spent ~31 min and ~$32 and shipped
clean, tested, lint-passing code around the *wrong* root cause — one confident, unverified
inference survived because nothing was built to attack it. The orchestrated recipe (~$19)
reached the correct root cause because two adversarial refuters killed the wrong theory before
it shipped.
**Why it matters:** Tier and effort harden *execution* — they buy more rigorous code. They do
not harden the *diagnosis*. Only independent, adversarial verification catches a wrong
diagnosis, and it is cheap next to shipping the wrong fix. More effort on a wrong premise just
yields a more polished wrong answer.
**How to apply:** On any ambiguous bug where the root cause is a judgment call, don't trust a
single agent's diagnosis no matter how high its tier or effort. Add step 4 (verify sideways)
with an explicit refute prompt before implementing. Spend on independence, not on a bigger
solo model.

## A mechanical-looking parse hid a tier trap
**What happened:** In the orchestrated run, a delegate-down step (a cheap model parsing an
export) returned a null for a field that a live API pull later contradicted. The extraction
looked mechanical but was nested/ambiguous enough that the cheapest tier got it wrong, and the
bad value briefly fed the driver's reasoning.
**Why it matters:** "Delegate down to the cheapest tier" is right for *truly* mechanical work,
but nested or ambiguous extraction is not as mechanical as it looks. An under-provisioned tier
there produces confident bad data that pollutes everything downstream.
**How to apply:** When a delegate-down step feeds a load-bearing fact, bump its tier or
cross-check the value against a second source before the driver builds on it. Cheap isn't free
if the output is wrong.
